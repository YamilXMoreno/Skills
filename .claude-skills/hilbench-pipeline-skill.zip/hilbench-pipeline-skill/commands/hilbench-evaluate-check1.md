---
description: Check 1 only (heavy; for targeted re-checks after a fix). Harbor SWE-Agent baseline grading (no blocker details) - build the image + baseline task, run 3 models x 2 runs, apply the Check 1 pass criteria. Delegates to the evaluate_task skill. Assumes input validation already passed.
argument-hint: "[optional: models, instance-id, or path overrides]"
---

Use the `hilbench-pipeline` skill for conventions, and delegate to the bundled `evaluate_task`
skill (read `evaluate_task/SKILL.md`, which ships with this package at
`~/.claude/skills/evaluate_task/`).

Scope: AUTHORITATIVE Harbor grading, HEAVY (6 SWE-Agent runs). Use this to re-check Check 1 on
its own after a fix, instead of re-running the whole `/hilbench-evaluate-full`. It is separate
from and stronger than the optional fast pre-screen `/hilbench-check1`.

Precondition: input validation (`/hilbench-validate-input`) has passed — SKIP input validation here.

Resolve `$TASK_FILES` / `$DELIVERABLES` and all inputs from disk exactly as
`evaluate_task/SKILL.md` step 1 describes (prefer the `$DELIVERABLES` obstructed artifacts).
$ARGUMENTS may override the model list.

Run ONLY the Check 1 path from `evaluate_task/SKILL.md`:
- Step 3 (image build) and Step 4 (task setup) for the BASELINE task `instruction.md`
  (problem statement + requirements + public interfaces; NO `# BLOCKER DETAILS`).
- Fire the 6 Check 1 runs (3 models x 2 runs) in parallel.
- Apply Step 5 criteria: Check 1 PASSES iff (a) at least 2 models FAIL the task AND (b) zero
  blockers are guessed.

Print `CHECK 1 (Harbor): PASS/FAIL` with per-component feedback (summaries of any passing
trajectories + their patches; any guessed blockers and which models/runs guessed them). STOP.
