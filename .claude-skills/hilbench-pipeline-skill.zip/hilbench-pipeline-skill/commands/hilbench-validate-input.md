---
description: Input validation (optional standalone; also run as the first step of /hilbench-evaluate-full) - structural input validation of the obstructed task (repo builds at base commit, test files exist, test-list coverage, patches apply cleanly). Delegates to the input_validation skill. Non-interactive.
argument-hint: "[optional: instance-id or path overrides]"
---

Use the `hilbench-pipeline` skill for path/stage conventions, and delegate the actual work
to the bundled `input_validation` skill (read `input_validation/SKILL.md`, which ships with
this package at `~/.claude/skills/input_validation/`, and follow it exactly).

This is distinct from the fast container Attempter Checks (`/hilbench-check1/2`): input validation
is structural validation that the obstructed task is buildable/applies cleanly, a precondition
for the heavier Harbor agentic checks.

Resolve `$TASK_FILES` and `$DELIVERABLES` first (print both). Resolve inputs from disk (only
ask if a required file is genuinely missing):
- instance id, repo, language, base image tag, base commit → `$TASK_FILES/task_info.txt`
- patches: Scenario 2 → `$DELIVERABLES/{test_patch_obstructed,golden_patch_obstructed}.diff`
  (+ `setup_patch.diff` if present); Scenario 1 → `$TASK_FILES/{test_patch,golden_patch}.diff`
- relevant tests → `$DELIVERABLES/relevant_tests.txt`

$ARGUMENTS may supply an instance-id or path overrides.

Run the skill's validation steps in order; early-exit on the first failing step with clear,
actionable feedback. On success print `INPUT VALIDATION: PASS`, then STOP. Do NOT auto-run
the agentic checks.
