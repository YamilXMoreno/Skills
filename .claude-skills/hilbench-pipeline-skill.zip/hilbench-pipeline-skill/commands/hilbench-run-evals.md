---
description: Reviewer tool - run the 12 static model evals verbatim against a completed task and report each PASS/FAIL, mirroring the async evaluation sheet. Default runs all 12; --from <file> runs only the evals flagged in a failing_items.txt. Read-only diagnostic; does not modify any artifact.
argument-hint: "[--from <path to failing_items.txt>]"
---

Use the `hilbench-pipeline` skill (read `SKILL.md` first). This is a **reviewer** diagnostic
that reproduces the static model-eval portion of the async evaluation sheet locally. It runs the
SAME prompts the authoring gates run — **verbatim from `references/eval-prompts.md`** — so it
introduces no new judgment. It is **read-only**: it reports results and never edits an artifact.

Follow `references/reviewer-evals.md` for the eval-name table, the `failing_items.txt`
convention, aliases, and output/sentinel rules.

Do this:

1. Resolve and print `$TASK_FILES` and `$DELIVERABLES`.

2. Decide which evals to run:
   - **No `--from`** → run **all 12** model evals.
   - **`--from <file>`** (default path `$DELIVERABLES/review/failing_items.txt`) → parse it per
     the convention in `references/reviewer-evals.md`: take the token before each `:`, match it
     to a full name/alias, and run **only** those evals. Ignore blank/`#` lines. For an
     unmatched token, print `UNRECOGNIZED_EVAL <token>` and skip it. For a `check1`/`check2`
     line, note it is a Harbor verdict (reproduce via `/hilbench-evaluate-check2`) and skip it.
     If the file is missing, STOP with `REQUIRED_INPUT_FILE_MISSING`.

3. For each selected eval, substitute its `{{placeholders}}` using the table at the top of
   `references/eval-prompts.md` and run the FULL prompt body **verbatim** (no paraphrase). On a
   completed task all inputs exist; run eval 7 as its full A/B/C prompt. If a required input is
   genuinely missing, mark that eval `REQUIRED_INPUT_FILE_MISSING` and continue with the rest.

4. Emit one line per eval, then a final summary line, then STOP:
   - `EVAL <full_name>: PASS` | `EVAL <full_name>: FAIL — <reason>`
   - Final: `EVALS: <passCount> PASS / <failCount> FAIL` (append `(<n> selected from <file>)`
     when `--from` was used).
   For each FAIL, add the fix-location hint from `references/reviewer-evals.md`. Do NOT apply any
   fix — the reviewer decides how to fix (there is no send-back).

This command never modifies the registry, modified specs, or patches, and never advances a
stage. After a fix, re-run **all 12** here (fixing one eval can regress another) rather than
re-checking a single flag.
