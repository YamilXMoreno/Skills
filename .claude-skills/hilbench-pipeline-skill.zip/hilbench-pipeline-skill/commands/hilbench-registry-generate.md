---
description: Authoring (one-shot) - generate blocker_registry.json/.md directly from the ORIGINAL task inputs using the Blocker Registry Generator. Alternative to the /hilbench-plan + /hilbench-registry two-step path. STOPS for review; always follow with /hilbench-validate-registry.
argument-hint: "[optional: distribution override]"
---

Use the `hilbench-pipeline` skill (read `SKILL.md` first). This is one of THREE ways to
author the registry (generator | numbered plan+registry | manual). Pick one.

Resolve `$TASK_FILES` and `$DELIVERABLES` first (print both). Read the ORIGINAL inputs from
`$TASK_FILES` (`task_info.txt`, `test_patch.diff`, `golden_patch.diff`) and the required
blocker distribution from `task_info.txt` ($ARGUMENTS may override it).

Follow `references/blocker-registry-generator.md` exactly. Generate directly from the
originals:
- Write `$DELIVERABLES/blocker_registry.json` (valid JSON per
  `references/blocker_registry.schema.json`).
- Write `$DELIVERABLES/blocker_registry.md` (identical human-readable mirror).
- Match the required distribution exactly. If it is missing, output `CONFIG_MISSING` and
  STOP.
- Print (chat only) the summary counts and the independence matrix.

Then STOP with `STAGE registry-generate: DONE`. Do NOT inject anything yet. The registry
is NOT trusted until it passes `/hilbench-validate-registry` — tell the contributor to run
that next (and to review the resolutions themselves, since they own the answer key).
