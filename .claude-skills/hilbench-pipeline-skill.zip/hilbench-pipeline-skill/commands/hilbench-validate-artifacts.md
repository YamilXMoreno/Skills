---
description: GATE (step 08) - patch-content validator + alignment map + the patch-dependent model evals (test_list, test_relevance, golden_patch, request, eval-7 necessity). Confirms relevant tests are in the test patch, each blocker resolution has an enforcing test, the golden patch implements the full spec + resolutions with nothing extra, the spec leaks nothing, and test/golden patches are cleanly separated. Runs in a fresh isolated chat.
argument-hint: ""
---

Use the `hilbench-pipeline` skill (read `SKILL.md` first). This is the SECOND hard gate,
run after injection and before the container-backed Attempter Checks. It is the alignment
gate that catches "text spec -> tests -> implementation" mismatches early, and it runs the
model evals that could not run at the registry gate because they need the patches.

Resolve `$TASK_FILES` and `$DELIVERABLES` first (print both). Require in `$DELIVERABLES`:
`modified_problem_statement.txt`, `modified_requirements.txt`,
`modified_public_interfaces.txt`, `relevant_tests.txt`, `test_patch_obstructed.diff`,
`golden_patch_obstructed.diff` (and `setup_patch.diff` if present). If any required file is
missing, STOP with `REQUIRED_INPUT_FILE_MISSING`.

Run this in a FRESH, isolated chat, in two parts:

**Part A — patch-content validator + alignment map.** Follow
`references/08-patch-content-validator.md` exactly:
- Provide ONLY the resolution list (id: resolution) as the blocker input — do NOT paste the
  full registry.
- Work through the workflow, returning FALSE on the first hard failure.
- Before returning TRUE, produce the mechanical ALIGNMENT MAP (one line per blocker id, plus
  one per multi-criteria requirement): `Spec anchor | Test anchor | Golden anchor`.
  (08 operationalizes evals 1/2/3 — test_list, test_relevance, golden_patch — plus overlap
  and separation rules and the alignment map, which are value-adds not in `model evals`.)

**Part B — patch-dependent model evals (run VERBATIM from `references/eval-prompts.md`).**
Now that the patches exist, run the evals that were deferred from the registry gate:
- `eval_request` (#12) — the modified spec does not leak any resolution, embed the solution,
  use a placeholder, narrate itself, or state a no-purpose requirement.
- `eval_blocker_critical_implementation` (#7) — **Test A (necessity) gate**: for each
  blocker, would at least one relevant test FAIL under the most plausible no-ask
  implementation? Test B/C were pre-screened at the registry gate; Check 1 confirms B
  empirically afterward. FAIL the gate on a Test A failure.

Emit the ALIGNMENT MAP, then each Part-B eval's `TRUE/FALSE`, then a single final line.

- On all-pass: `ARTIFACTS GATE: PASS` — proceed to `/hilbench-validate-obstructed`.
- On any FALSE: `ARTIFACTS GATE: FAIL - <which eval + reason>` — prefer fixing the golden
  patch or adding the missing enforcing test (see `references/optional-repair.md`); for an
  `eval_request` leak, fix the modified spec text; do NOT weaken tests. Re-run this gate
  after repair. Do not run the Attempter Checks until this passes.

### Save the results (required)

After emitting the verdict, write the full result to
`$DELIVERABLES/validate_artifacts_result.txt` (overwrite) so the gate outcome is captured with
the deliverables. Include, in order:
- a header line with a UTC timestamp,
- Part A: the `TRUE`/`FALSE` line plus the full ALIGNMENT MAP (one line per blocker id / multi-criteria requirement),
- Part B: each eval's `TRUE/FALSE` with its one-line reason,
- the final `ARTIFACTS GATE: PASS` / `ARTIFACTS GATE: FAIL - <reason>` line.

Do NOT write any diff content or blocker resolutions into this file. This results file is the
ONLY file this gate may write — do not modify any of the artifacts under validation.
