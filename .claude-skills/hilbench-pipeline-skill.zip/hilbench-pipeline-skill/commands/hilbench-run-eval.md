---
description: Reviewer tool - run ONE of the 12 static model evals (by name) verbatim against a completed task, to reproduce/verify a single flag from the async evaluation sheet. Read-only diagnostic; does not modify any artifact. Same prompt the authoring gates run.
argument-hint: "<eval_name>  (e.g. eval_request | independence | golden_patch)"
---

Use the `hilbench-pipeline` skill (read `SKILL.md` first). This is a **reviewer** diagnostic:
it runs a single model eval so a reviewer can reproduce or re-verify one failing flag from the
async evaluation sheet, without running a whole gate. It is **read-only** — it reports
`PASS`/`FAIL` and never edits an artifact.

Follow `references/reviewer-evals.md` for the eval-name table, aliases, and rules; run the
prompt body **verbatim** from `references/eval-prompts.md`.

Do this:

1. Resolve and print `$TASK_FILES` and `$DELIVERABLES`.

2. Parse `$ARGUMENTS` as a single eval name (full `eval_*` or short alias, case-insensitive).
   - If it is not one of the 12 in `references/reviewer-evals.md`, STOP with
     `UNRECOGNIZED_EVAL <token>` and print the list of valid names.
   - If it is `check1` / `check2`, STOP and tell the reviewer these are Harbor verdicts — the
     async sheet does not ship the agent patches to diagnose, so reproduce with
     `/hilbench-evaluate-check2` instead.

3. Gather the eval's inputs by substituting its `{{placeholders}}` using the table at the top of
   `references/eval-prompts.md` (completed-task artifacts under `$DELIVERABLES`, originals under
   `$TASK_FILES`). If a required input file is missing, STOP with `REQUIRED_INPUT_FILE_MISSING`
   and name it. (On a completed task, run eval 7 as its FULL prompt — Tests A, B, and C.)

4. Run the FULL prompt body **verbatim** — do NOT paraphrase or condense; its carve-outs prevent
   false-positive FALSEs.

5. Emit exactly one result line, then STOP:
   - `EVAL <full_name>: PASS`, or
   - `EVAL <full_name>: FAIL — <the eval's own one-line reason>`
   On FAIL, add the fix-location hint for that eval from `references/reviewer-evals.md`, but do
   NOT apply any fix — the reviewer decides how to fix (there is no send-back).

Never modify the registry, modified specs, or patches. Never auto-run other evals or advance a
stage.
