#!/usr/bin/env bash
# Install the self-contained hilbench-pipeline package into ~/.claude/.
# Ships three skills (hilbench-pipeline + the bundled input_validation / evaluate_task
# grading skills) plus the /hilbench-* slash commands. Additive: does not modify the
# older hilbench-blocker-injection / hilbench-evaluation packages if they are also present.
set -euo pipefail

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

CLAUDE_SKILLS_DIR="${CLAUDE_SKILLS_DIR:-$HOME/.claude/skills}"
CLAUDE_COMMANDS_DIR="${CLAUDE_COMMANDS_DIR:-$HOME/.claude/commands}"

echo "Installing hilbench-pipeline (self-contained)"
echo "  skills   -> $CLAUDE_SKILLS_DIR/ (hilbench-pipeline, input_validation, evaluate_task)"
echo "  commands -> $CLAUDE_COMMANDS_DIR"

mkdir -p "$CLAUDE_SKILLS_DIR" "$CLAUDE_COMMANDS_DIR"

# Skills: hilbench-pipeline (body) + the bundled grading skills.
for s in "$SRC_DIR"/skills/*/; do
  name="$(basename "$s")"
  rm -rf "$CLAUDE_SKILLS_DIR/$name"
  cp -R "$s" "$CLAUDE_SKILLS_DIR/$name"
done

# Slash commands.
cp "$SRC_DIR"/commands/*.md "$CLAUDE_COMMANDS_DIR/"

# Make bundled scripts executable (skill-root and nested scripts/ dirs).
chmod +x "$CLAUDE_SKILLS_DIR"/*/*.sh "$CLAUDE_SKILLS_DIR"/*/scripts/*.sh 2>/dev/null || true

echo "Done."
echo "Installed skills:"
ls -1 "$CLAUDE_SKILLS_DIR" | grep -E '^(hilbench-pipeline|input_validation|evaluate_task)$' || true
echo "Installed commands:"
ls "$CLAUDE_COMMANDS_DIR" | grep '^hilbench-' || true
