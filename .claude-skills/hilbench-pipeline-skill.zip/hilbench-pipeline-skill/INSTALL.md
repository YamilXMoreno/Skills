# Install: hilbench-pipeline package (self-contained)

This installs the segmented HiL-Bench pipeline **and the grading skills it delegates to**
(`input_validation` + `evaluate_task`) plus all `/hilbench-*` slash commands into
`~/.claude/`. The package is self-contained — you do NOT need the separate
`hilbench-evaluation` package for the Stage-5 evaluation commands. It is additive and does
not modify the older `hilbench-blocker-injection` / `hilbench-evaluation` packages if they
happen to be installed too.

## Contents

```
skills/hilbench-pipeline/   # orchestration skill (SKILL.md + references/ + scripts/ + docs)
skills/input_validation/    # bundled structural input-validation skill
skills/evaluate_task/        # bundled Harbor SWE-Agent grading skill (+ sandbox proxy scripts)
commands/*.md               # the /hilbench-* slash commands
install.sh                  # copies the three skills + commands into ~/.claude/
```

## Quick install

From this directory:

```bash
bash install.sh
```

This copies:

- `skills/hilbench-pipeline/`, `skills/input_validation/`, `skills/evaluate_task/` -> `~/.claude/skills/`
- `commands/*.md` -> `~/.claude/commands/`

and marks the bundled shell scripts executable.

## Custom skills/commands roots

Override the destinations if your CLI uses different roots:

```bash
CLAUDE_SKILLS_DIR="$HOME/.claude/skills" \
CLAUDE_COMMANDS_DIR="$HOME/.claude/commands" \
bash install.sh
```

## Verify

```bash
ls ~/.claude/skills/hilbench-pipeline ~/.claude/skills/input_validation ~/.claude/skills/evaluate_task
ls ~/.claude/commands | grep hilbench-
```

Then in a chat run `/hilbench-provision` to confirm the commands are discoverable.

## Uninstall

```bash
rm -rf ~/.claude/skills/hilbench-pipeline ~/.claude/skills/input_validation ~/.claude/skills/evaluate_task
rm -f ~/.claude/commands/hilbench-*.md
```

Note: if you also have the standalone `hilbench-evaluation` package installed, removing
`input_validation` / `evaluate_task` here will remove the copies it shares — reinstall that
package if you still need it independently.
